README for Qt-DLLs

- Qt DLLs and plugins needed by KDiff3 (64 bit version)
  http://qt-project.org

  License:  GPL v3 or LGPL v2.1
					   